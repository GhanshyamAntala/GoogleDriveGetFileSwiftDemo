//
//  FileModel.swift
//  GoogleDrive
//
//  Created by SENSUSSOFT on 7/4/18.
//  Copyright © 2018 SENSUSSOFT. All rights reserved.
//

import UIKit

class FileModel: NSObject {

    var fileName : String? = ""
    var fileId : String? = ""
    var fileMimeType : String? = ""
    
}
