//
//  ViewController.swift
//  GoogleDrive
//
//  Created by SENSUSSOFT on 7/4/18.
//  Copyright © 2018 SENSUSSOFT. All rights reserved.
//

import UIKit
import GTMOAuth2
import GoogleAPIClientForREST
import GoogleSignIn

private let kKeychainItemName = "GoogleDrive"
private let kClientID = "1062621122286-mt9mkbnba98570ttflgrbp1krslgqbmi.apps.googleusercontent.com"
private let kClientSecret = ""

class ViewController: UIViewController {
    
    @IBOutlet weak var tblList: UITableView!
    @IBOutlet weak var viewNoDataFound: UIView!
    
    var serviceGdrive : GTLRDriveService!
    var arrFileList = [FileModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        viewNoDataFound.isHidden = true
        tblList.tableFooterView = UIView()
        tblList.register(UINib(nibName: "GoogleDriveFileListCell", bundle: nil), forCellReuseIdentifier: "GoogleDriveFileListCell")
        tblList.delegate = self
        tblList.dataSource = self
        
        LoginGoogel()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewDidAppear(_ animated: Bool) {
        navigationController?.setNavigationBarHidden(false, animated: false)
        if !(serviceGdrive.authorizer?.canAuthorize)! {
            // Not yet authorized, request authorization by pushing the login UI onto the UI stack.
            present(createAuthController()!, animated: true)
        } else {
            listFiles()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    func LoginGoogel()
    {
        let dictionary = [
            "UserAgent" : "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
        ]
        UserDefaults.standard.register(defaults: dictionary)
        // Initialize the Drive API service & load existing credentials from the keychain if available.
        serviceGdrive = GTLRDriveService()
        serviceGdrive.authorizer = GTMOAuth2ViewControllerTouch.authForGoogleFromKeychain(forName: kKeychainItemName, clientID: kClientID, clientSecret: kClientSecret)
    }
    
    func listFiles() {
        let query = GTLRDriveQuery_FilesList.query()
        // query.fields = @"nextPageToken, files(id, name, mimeType)";
        // query.pageSize = 100;
        // query.q = @"mimeType = 'application/msword' or mimeType = 'application/pdf'";
//        serviceGdrive.executeQuery(query, delegate: self, didFinish: #selector(displayResult(_:_:_:)))
        
        serviceGdrive.executeQuery(query) { (ticket, result, error) in
            print(ticket)
            print(result)
            print(error)
            
            self.displayResult(ticket, result as? GTLRDrive_FileList, error)
        }
    }
    
    @objc func displayResult(_ ticket: GTLRServiceTicket?,_ result: GTLRDrive_FileList? ,_ error : Error?)  {
        if error == nil {
            if result?.files?.count ?? 0 > 0 {
                for file: GTLRDrive_File? in result?.files ?? [GTLRDrive_File?]() {
                    if let aJSON = file?.json {
                        print("files: \(aJSON)")
                    }
                    if let aName = file?.name {
                        print("file extension: \(aName)")
                    }
                    let obj = FileModel()
                    obj.fileId = file?.identifier
                    obj.fileName = file?.name
                    obj.fileMimeType = file?.mimeType
                    arrFileList.append(obj)
                }
                if arrFileList.count > 0 {
                    viewNoDataFound.isHidden = true
                    tblList.isHidden = false
                }else
                {
                    viewNoDataFound.isHidden = false
                    tblList.isHidden = true
                }
                tblList.reloadData()
            }else
            {
                print("no file found")
            }
            }else
        {
            var message = String()
            message += "Error getting presentation data: \(error?.localizedDescription )\n"
            showAlert("Error", message: message)
        }
        
    }

    //  Converted to Swift 4 by Swiftify v4.1.6751 - https://objectivec2swift.com/
    func createAuthController() -> GTMOAuth2ViewControllerTouch? {
        var authController: GTMOAuth2ViewControllerTouch?
        // If modifying these scopes, delete your previously saved credentials by
        // resetting the iOS simulator or uninstall the app.
        let scopes = [kGTLRAuthScopeDrive]
        authController = GTMOAuth2ViewControllerTouch(scope: scopes.joined(separator: " "), clientID: kClientID, clientSecret: nil, keychainItemName: kKeychainItemName, delegate: self, finishedSelector: #selector(viewController(_:finishedWithAuth:error:)))
        return authController
    }

    @objc func viewController(_ viewController: GTMOAuth2ViewControllerTouch?, finishedWithAuth authResult: GTMOAuth2Authentication?, error : Error) throws {
        if error != nil {
            showAlert("Authentication Error", message: error.localizedDescription)
            serviceGdrive.authorizer = nil
        } else {
            serviceGdrive.authorizer = authResult
            dismiss(animated: true)
        }
    }
    
   
    
    func showAlert(_ title: String?, message: String?) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { action in
            alert.dismiss(animated: true)
        })
        alert.addAction(ok)
        present(alert, animated: true)
    }
    
    @IBAction func btnSignOut(_ sender: Any) {
        //LoginGoogel()
    }
    
    func selectGoogleDriveFile(_ fileData: Data?, extenstion fileExtension: String?, name fileName: String?) {
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrFileList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tableView.dequeueReusableCell(withIdentifier: "GoogleDriveFileListCell") as! GoogleDriveFileListCell
        if cell == nil {
            var nib = Bundle.main.loadNibNamed("GoogleDriveFileListCell", owner: self, options: nil)
            cell = nib?[0] as! GoogleDriveFileListCell
        }
        let obj = arrFileList[indexPath.row]
        if let aName = obj.fileName {
            print("\(aName)")
        }
        if let aType = obj.fileMimeType {
            print("\(aType)")
        }
        if let anId = obj.fileId {
            print("\(anId)")
        }
        if let aName = obj.fileName {
            cell.lblFileName.text = "\(aName)"
        }
        return cell
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let obj = arrFileList[indexPath.row]
        var extenstion: String = ""
        if (obj.fileMimeType == "application/zip") || (obj.fileMimeType == "application/rar") || (obj.fileMimeType == "application/emb") {
            if (obj.fileMimeType == "application/zip") {
                extenstion = "zip"
            } else if (obj.fileMimeType == "application/rar") {
                extenstion = "rar"
            } else if (obj.fileMimeType == "application/emb") {
                extenstion = "emb"
            }
            let query: GTLRQuery? = GTLRDriveQuery_FilesGet.queryForMedia(withFileId: (obj.fileId)!)
        
//        CommonUtility.showGlobalHUD()
            (serviceGdrive.executeQuery(query!, completionHandler: { (ticket, file, error) in
                if error == nil {
                    self.selectGoogleDriveFile((file as AnyObject).data, extenstion: extenstion, name: obj.fileName)
                    
                    self.navigationController?.popViewController(animated: true)
                    
                }else
                {
                    print("An error occurred ")
                }
            }))
        
        }else if obj.fileMimeType == "application/vnd.google-apps.folder"
        {
            let query = GTLRDriveQuery_FilesGet.query(withFileId: obj.fileId!)
            (serviceGdrive.executeQuery(query, completionHandler: { ticket, file, error in
                if let aFile = file {
                    print("file: \(aFile)")
                }
            }))
        }else
        {
            showAlert("Error", message: "Only zip,rar,emb files are accepted. please select other file for download.")
        }
    }
}
