//
//  GoogleDriveFileListCell.swift
//  GoogleDrive
//
//  Created by SENSUSSOFT on 7/4/18.
//  Copyright © 2018 SENSUSSOFT. All rights reserved.
//

import UIKit

class GoogleDriveFileListCell: UITableViewCell {

    @IBOutlet weak var lblFileName: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
